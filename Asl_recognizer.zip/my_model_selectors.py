import math
import statistics
import warnings

import numpy as np
from hmmlearn.hmm import GaussianHMM
from sklearn.model_selection import KFold
from asl_utils import combine_sequences


class ModelSelector(object):
    '''
    base class for model selection (strategy design pattern)
    '''

    def __init__(self, all_word_sequences: dict, all_word_Xlengths: dict, this_word: str,
                 n_constant=3,
                 min_n_states=2, max_n_states=10,
                 random_state=14, verbose=False):
        self.words = all_word_sequences
        self.hwords = all_word_Xlengths
        self.sequences = all_word_sequences[this_word]
        self.X, self.lengths = all_word_Xlengths[this_word]
        self.this_word = this_word
        self.n_constant = n_constant
        self.min_n_states = min_n_states
        self.max_n_states = max_n_states
        self.random_state = random_state
        self.verbose = verbose

    def select(self):
        raise NotImplementedError

    def base_model(self, num_states):
        # with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        # warnings.filterwarnings("ignore", category=RuntimeWarning)
        try:
            hmm_model = GaussianHMM(n_components=num_states, covariance_type="diag", n_iter=1000,
                                    random_state=self.random_state, verbose=False).fit(self.X, self.lengths)
            if self.verbose:
                print("model created for {} with {} states".format(self.this_word, num_states))
            return hmm_model
        except:
            if self.verbose:
                print("failure on {} with {} states".format(self.this_word, num_states))
            return None


class SelectorConstant(ModelSelector):
    """ select the model with value self.n_constant

    """

    def select(self):
        """ select based on n_constant value

        :return: GaussianHMM object
        """
        best_num_states = self.n_constant
        return self.base_model(best_num_states)


class SelectorBIC(ModelSelector):
    """ select the model with the lowest Bayesian Information Criterion(BIC) score

    http://www2.imm.dtu.dk/courses/02433/doc/ch6_slides.pdf
    Bayesian information criteria: BIC = -2 * logL + p * logN
    """

    def select(self):
        """ select the best model for self.this_word based on
        BIC score for n between self.min_n_components and self.max_n_components

        :return: GaussianHMM object
        """
        warnings.filterwarnings("ignore", category=DeprecationWarning)

        # TODO implement model selection based on BIC scores
        # Compute BIC score of each model and keep track of the one with minimum BIC.
        # Return the one with lower complexity if two BICs are both minnimums.
        best_num_states, lowest_BIC = None, None
        for num_states in range(self.min_n_states, self.max_n_states + 1):
            try:
                logL = self.base_model(num_states).score(self.X, self.lengths)
                logN = np.log(len(self.X))
                # Ref: https://discussions.udacity.com/t/number-of-parameters-bic-calculation/233235/
                # p = num_free_params = ("transition probs" == n*n) + means(n*f) + covars(n*f).

                
                # p = num_free_params = init_state_occupation_probs + transition_probs + emission_probs
                #     = ( num_states ) +
                #       ( num_states * (num_states - 1) ) +
                #       ( num_states * num_data_points * 2 )
              
                # p = num_free_params * (num_states - 1) - num_zeros_in_transiton_matrix
               
                # Transition matrix: N x N matrix, where N is the number of states. 
                #   The free parameters for the transition matrix is N * (N - 1). 
                # Emission matrix: Covariance_type is "diag" by default", if the model has M features, then there are M means and M diagonal values in the covariance matrix, for 2 * M per state. 
                #   The final total is 2 * theNumberOfStates * theNumberOfFeatures.
                
                p = num_states * (num_states-1) + 2 * len(self.X[0]) * num_states
                BIC = -2 * logL + p * logN
                if lowest_BIC is None or lowest_BIC > BIC:
                    lowest_BIC, best_num_states= BIC, num_states
            except:
                pass

        if best_num_states is None:
            return self.base_model(self.n_constant)
        else:
            return self.base_model(best_num_states)


class SelectorDIC(ModelSelector):
    ''' select best model based on Discriminative Information Criterion

    Biem, Alain. "A model selection criterion for classification: Application to hmm topology optimization."
    Document Analysis and Recognition, 2003. Proceedings. Seventh International Conference on. IEEE, 2003.
    http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.58.6208&rep=rep1&type=pdf
    https://pdfs.semanticscholar.org/ed3d/7c4a5f607201f3848d4c02dd9ba17c791fc2.pdf
    DIC = log(P(X(i)) - 1/(M-1)SUM(log(P(X(all but i))
    '''

    ''' def select(self):
        warnings.filterwarnings("ignore", category=DeprecationWarning)

        # TODO implement model selection based on DIC scores
        best_num_states, highest_DIC = None, None
        for num_states in range(self.min_n_states, self.max_n_states + 1):
            try:
                log_P_X_i = self.base_model(num_states).score(self.X, self.lengths)

                sum_log_P_X_all_but_i = 0.
                words = list(self.words.keys())
                M = len(words)
                words.remove(self.this_word)

                for word in words:
                    try:
                        model_selector_all_but_i = ModelSelector(self.words, self.hwords, word, self.n_constant, self.min_n_states, self.max_n_states, self.random_state, self.verbose)
                        sum_log_P_X_all_but_i += model_selector_all_but_i.base_model(num_states).score(model_selector_all_but_i.X, model_selector_all_but_i.lengths)
                    except:
                        M = M - 1

                DIC = log_P_X_i - sum_log_P_X_all_but_i / (M - 1)

                if highest_DIC is None or highest_DIC < DIC:
                  highest_DIC, best_num_states = DIC, num_states
            except:
                pass

        if best_num_states is None:
            return self.base_model(self.n_constant)
        else:
            return self.base_model(best_num_states)
    '''
    def select(self):
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        warnings.filterwarnings("ignore", category=RuntimeWarning)
        # TODO implement model selection based on DIC scores
        other_words = []
        models = []
        score_dics = []
        for word in self.words:
            if word != self.this_word:
                other_words.append(self.hwords[word])
        try:
            for num_states in range(self.min_n_states, self.max_n_states + 1):
                hmm_model = self.base_model(num_states)
                log_likelihood_original_word = hmm_model.score(self.X, self.lengths)
                models.append((log_likelihood_original_word, hmm_model))

        # Note: Situation that may cause exception may be if have more parameters to fit
        # than there are samples, so must catch exception when the model is invalid
        except Exception as e:
            # logging.exception('DIC Exception occurred: ', e)
            pass
        for index, model in enumerate(models):
            log_likelihood_original_word, hmm_model = model
            score_dic = log_likelihood_original_word - np.mean(self.calc_log_likelihood_other_words(model, other_words))
            score_dics.append(tuple([score_dic, model[1]]))
        return self.calc_best_score_dic(score_dics)[1] if score_dics else None
    
    def calc_log_likelihood_other_words(self, model, other_words):
        return [model[1].score(word[0], word[1]) for word in other_words]

    def calc_best_score_dic(self, score_dics):
        # Max of list of lists comparing each item by value at index 0
        return max(score_dics, key = lambda x: x[0])

class SelectorCV(ModelSelector):
    ''' select best model based on average log Likelihood of cross-validation folds

    '''
    
    
    def select(self):
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        warnings.filterwarnings("ignore", category=RuntimeWarning)
        # TODO implement model selection using CV
        k_fold = KFold(n_splits = 3, random_state = 42, shuffle = False)
        best_num_states, highest_avg_logL = None, None
        for num_states in range(self.min_n_states, self.max_n_states + 1):
            sum_logL = 0.
            count_logL = 0
            try:
                
                for train_index, test_index in k_fold.split(self.sequences):
                    X, lengths = combine_sequences(train_index,self.sequences)

                    try:
                        sum_logL += self.base_model(num_states).score(X, lengths)
                        count_logL += 1
                    except:
                        pass

                if count_logL > 0:
                    avg_logL = sum_logL / count_logL
                    if highest_avg_logL is None or highest_avg_logL < avg_logL:
                      highest_avg_logL, best_num_states = avg_logL, num_states
                      
                      
                      
            except:
                pass

        if best_num_states is None:
            return self.base_model(self.n_constant)
        else:
            return self.base_model(best_num_states)


